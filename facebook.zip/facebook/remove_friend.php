<?php
     include 'connect.php';
     session_start();
      $recever=$_GET['id'];
      echo $recever;
      $sender_id=$_SESSION['userid'];
      echo $sender_id;
      
      $query="delete from req_accept where recever=$recever and sender=$sender_id";
      $run=mysqli_query($conn,$query);
      $q="delete from addfriend where user_id=$recever and friend_id=$sender_id";
      $res=mysqli_query($conn,$q);

      header('location:friend_list.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>