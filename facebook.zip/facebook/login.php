<?php
session_start();
include 'connect.php';

$db = mysqli_select_db($conn, 'facebook');


$emailerr = $passerr = $password = $error="";

if (isset($_POST['submit'])) {

    if (empty($_POST["email"])) {
        $emailerr = "email is mandatory";
    }
    else{
        $emailerr='';
    }

    if (empty($_POST["password"])) {
        $passerr = "password is mandatory";
    } else {
        $password = $_POST['password'];
    }


    if (isset($_SESSION['email'])) {
        $_SESSION['email'] = $email;
    }
    $email = $_POST['email'];
    // $password = $_POST['password'];

    $pass = md5($password);

    if(empty($passerr)){
    $sql = "select * from signup where email='$email' and password='$pass'";
    
    if ($query = mysqli_query($conn, $sql)) {
        if (mysqli_num_rows($query) == 1) {
            $_SESSION['email'] = $email;
            $_SESSION['userid'] = $id;
            echo 'successfully login';
            header('location:home.php');
            
        } else {
            $error= 'wrong email or password';
        }
    } else {
        echo 'query fail';

        // header('location:login2.php');
    }
}
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
    <title>Document</title>
    <script type="text/javascript">
        function preventBack() {
            window.history.forward()
        };
        setTimeout("preventBack()", 0);
        window.onunload = function() {
            null
        }
    </script>

</head>
<style>
    .container {

        box-shadow: 10px 10px 8px 10px #888888;

    }

    h2 {
        color: green;
    }
    h3{
        color: #166fe5;
    }
    .card{
              box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
              transition: 0.3s;
              border-radius: 5px;
              width: 350px;
              height: 270px;
    }
    .card:hover{
        box-shadow: 0,8px 16px,0 rgba(0,0,0,0.2);
    }
    button{
        width: 300px;
        height: 40px;
        background-color: #166fe5;
    }
    a{
         padding-top: 10px;
         text-decoration: none;
         color: #166fe5;
         margin-top: 10px;
    }
    #error{
        margin-top: 50px;
        color: red;
        font-size: 20px;
        text-transform: capitalize;

    }
    .errorColor{
        color: red;
    }
</style>

<body>

    <center>
        <div id="error">   <h4><?php echo $error ?><h4> </div>
         <div>
             <img src="assets/facebook.png" width="200px" height="90px"/>
         </div>
          <div class="card">
            <h3>Log In Facebook</h3><br>
            
            <center>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

                    <input type="email" class="input2" name="email" value="" placeholder="Email" autocomplete="off" id="login" /><br>
                    <span class=" errorColor"> <?php  echo $emailerr; ?></span>
                    <br><br>

                    <input type="password" class="input2" name="password" value="" placeholder="Password" autocomplete="off" id="login" /><br>
                    <span class="errorColor"> <?php echo $passerr; ?></span>
                    <br><br>


                    <button type="submit" name="submit" class="button">Login</button>
                    <br><a href="forgot.php">Forgotten password?</a>
                    <br><span>Have a account?</span><span> <a href="signup.php">SignUp Here</a></span>

                </form>


            </center>
        </div>

    

</body>

</html>