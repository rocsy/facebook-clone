<?php
include 'connect.php';
session_start();
$ids = $_SESSION['userid'];
echo $ids;

echo $myid;

$id = $_GET['id'];

$_SESSION['friend_id'] =$id;
echo $id;
$friend_id = $id;
$query = "insert into addfriend (user_id,friend_id) values($ids,$friend_id)";
$run = mysqli_query($conn, $query);
header('location:addfriend.php');


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">     
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <title>Document</title>
</head>

<body>
    



<!-- <script>
        $(document).ready(function() {
            $("#btn").onchange(function(event) {
                event.preventDefault();
                 
                var id = $("#id").val();
                console.log(id);
                 

                $.ajax({
                    url: "addfriend.php",
                    method: "POST",
                    data: {id:id},

                    // cache: false, //for image
                    // contentType: false,
                    // processData: false,
                    success: function(data) {
                        $("#btn").html('request sending');
                        console.log(data);
                    }
                });
            })
        })
    </script> -->
</body>

</html>