<?php

include 'connect.php';
// if(isset($_GET['id']))
// {
// $id=$_GET['id'];
// echo $id;
// }
// 
?>
<?php include 'bfnavbar.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<style>
    .profile {
        width: 220px;
        height: 110px;
        margin-top: 30px;
        justify-content: center;
        margin-left: 500px;
        background-color: whitesmoke;
        padding: 10px 10px;
        padding-left: 15px;
        border: 1px solid blue;
        border-radius: 5px;
        box-shadow: 2px 2px 2px 2px;
    }

    a {
        text-decoration: none;
    }

    .card-img-top {
        height: 100px;
        width: 100px;
    }

    .card {
        width: 150px !important;
        align-items: center;
        text-transform: capitalize;
        font-weight: 500;
    }
    .card:hover{
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }
</style>

<body>
    <div class="container my-4  col-4">
        <div class="row">
            <?php

            $selectQuery = " select * from signup ";
            $query = mysqli_query($conn, $selectQuery);
            // $nums=mysqli_num_rows($query); //for no of rows in my database
            while ($res = mysqli_fetch_array($query)) {


            ?>

                <div class="col-sm-4 my-2">
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src="upload/<?php echo $res['profile'] ?>" alt="Card image cap">
                        <div class="card-body">
                            <?php echo $res['firstname'] ?><?php echo $res['lastname'] ?><br>
                            <button class="btn btn-warning clickbutton" type="button" id="<?php echo $res['id'] ?>">
                                addfriend
                            </button>
                        </div>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>
    <script>
        // $("button").click(function() {
        //     alert(this.id); // or console.log($(this).attr('id'));
        // });
        //  $(document).ready(function() {
        $(".clickbutton").click(function(event) {
            event.preventDefault();
            // var id = $('#myid').val();   
            var id = this.id;
            $(this).text("sending..");
            console.log(id);
            $.ajax({
                url: "showfriend.php?id=" + id,
                data: {
                   id: id
                },
                type: 'post',
                success: function(response) {
                    // $(".clickbutton").click(function() {
                    //     var id=this.id;
                    //     $(this).text("sending..");
                    // });
                }
            });
        });
    </script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>