<?php

include 'connect.php';
$id =  $_SESSION['userid'];

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .container {
        margin-top: 10px;
        width: 450px;
        height: 400px;
        border: orange;
        border-radius: 10px;
        align-items: center;
        justify-content: center;
        display: flex;

    }

    .img1 {
        border-radius: 20px;
    }

    .card1 {
        margin-top: 30px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        transition: 0.3s;
        border-radius: 5px;
        width: 500px;
        height: auto;
        padding-bottom: 10px;
    }

    .card:hover {
        box-shadow: 0, 8px 16px, 0 rgba(0, 0, 0, 0.2);
    }
    #userpost{
        font-weight: bolder;
        float: left;
        margin: 5px;
    }
</style>

<body>

    <div class="content">

        <?php
        $tempArr = array();
        $selectQuery = "SELECT * FROM `req_accept` WHERE  sender='$id'";
        $query = mysqli_query($conn, $selectQuery);
        while ($res = mysqli_fetch_array($query)) {

            array_push($tempArr, $res['sender'], $res['recever']);
        }
        $mylist = array_unique($tempArr);
        $myarr = implode(',', $mylist);


        if (!empty($myarr)) {
            // $selectQuery = "select * from post where uploader in ($myarr)";
            $selectQuery = "select * from signup join post on signup.id=post.uploader where post.uploader in ($myarr)";

            $query = mysqli_query($conn, $selectQuery);
        } else {
            // $selectQuery = "select * from post where uploader ='$id'";
            $selectQuery = "select * from signup join post on signup.id=post.uploader where post.uploader='$id'";

            $query = mysqli_query($conn, $selectQuery);
        }
        while ($res = mysqli_fetch_array($query)) { ?>
            <div class="card1">
              <div id="userpost">
                <img src="upload/<?php echo $res['profile'] ?> " class="" width="50" height="50px" ? />
                <span ><?php echo strtoupper($res['firstname']." ".$res['lastname']) ?></span>
              </div>
                <br><img src="upload/<?php echo $res['image']; ?> " class="img1" width="400" height="300px" ? /><br>
                <span> <?php $id ?>
                    <?php echo $res['message'] ?>

                    <?php
                    $result = mysqli_query($conn, "select * from likes where userid= $id  AND postid = " . $res['id'] . " ");

                    if (mysqli_num_rows($result)) { ?>

                        <span> <a href="" class="unlike" id="<?php echo $res['id'] ?>">unlike👍</a></span>
                        <span><?php echo $res['likes']; ?></span>


                    <?php } else { ?>
                        <span> <a href="" class="like" id="<?php echo $res['id'] ?>">like👍</a></span>
                        <span><?php echo $res['likes']; ?></span>
                    <?php } ?>
            </div>
        <?php
        }
        ?>

    </div>

    <script>
        $(document).ready(function() {

            $('.like').click(function(e) {
                e.preventDefault();

                var postid = $(this).attr('id');

                // alert(postid);
                $.ajax({
                    url: 'like_dislike_auth.php',
                    type: 'post',
                    async: false,
                    data: {
                        'liked': 1,
                        'postid': postid
                    },
                    success: function(result) {
                        console.log(result);
                        if (result) {
                            location.reload();
                        }

                    }
                });

            });


            $('.unlike').click(function(e) {
                e.preventDefault();
                var postid = $(this).attr('id');
                $.ajax({
                    url: 'like_dislike_auth.php',
                    type: 'post',
                    async: false,
                    data: {
                        'unliked': 1,
                        'postid': postid
                    },
                    success: function(result) {
                        console.log(result);
                        if (result) {
                            location.reload();
                            
                        }

                    }

                });
            });


        });
    </script>
</body>

</html>