<?php

include 'connect.php';
session_start();
// $token = $_GET['token'];
// $_SESSION['token'] = $token;
// echo $_SESSION['token'];
$passerr = '';
$email = $_SESSION['email'];
if (isset($_POST['submit'])) {

    if (empty($_POST['password'])) {
        $passerr = 'password must have entered';
    } else {
        $password = $_POST['password'];
        $uppercase = preg_match('@[A-Z]@', $password);
        $lowercase = preg_match('@[a-z]@', $password);
        $number    = preg_match('@[0-9]@', $password);
        $specialChars = preg_match('@[^\w]@', $password);

        if (strlen($password) < 8) {
            $passerr = 'Password should be at least 8 characters ';
        }
        if (!$uppercase) {
            $passerr = 'one uppercase mandatory';
        }
        if (!$lowercase) {
            $passerr = 'one lowercase mandatory';
        }
        if (!$specialChars) {
            $passerr = 'one specialChars mandatory';
        }
        if (!$number) {
            $passerr = 'one number mandatory';
        } else {
            $password = $_POST['password'];
        }

       
    }
    if (empty($passerr)) {

        $password = $_POST['password'];
        $pass = md5($password);
        $email = $_SESSION['email'];
        echo $email;
        echo $password;
        $query = "update signup set password = '$pass' where email='$email'";
        print_r($query);
        $run = mysqli_query($conn, $query);
        if ($run) {
            header('location:passwordreset.php');
        } else {
            echo 'fail';
        }
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    h2 {
        padding-top: 50px;
        color: rgb(9, 36, 245);
        margin-bottom: 20px;
    }


    .card1 {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            padding: 30px;
            transition: 0.3s;
            border-radius: 5px;
            width: 300px;
            height: auto;
        }

        .card1:hover {
            box-shadow: 0, 8px 16px, 0 rgba(0, 0, 0, 0.2);
        }

    input {
        width: 200px;
        height: 25px;

    }

    button {
        height: 30px;
        width: 150px;
        color: white;
        background-color: blue;
        border: none;
    }
</style>

<body>
    <center>
        <div>
            <h2>Forgotten Password </h2>
            <div class="card1">

                <form method="post" action="<?php echo  htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                    <input type="password" name="password" placeholder="New Password"><br><br>
                    <?php echo $passerr;  ?>
                    <button type="submit" name="submit">Password Reset</button>

                </form>
                <a href="login.php">Already have an account</a>

            </div>
        </div>
    </center>


</body>

</html>