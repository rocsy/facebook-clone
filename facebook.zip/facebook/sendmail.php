<?php
ini_set("smtp_port","25");

$to_email = "atul19462@gmail.com";
$subject = "Test email to send from XAMPP";
$body="hi, click here too activate your account 
http://localhost/php/facebook/activate.php?token ";
// $sender_email="From: testingtest123testing01@gmail.com";
$headers = "From:testingtest123testing01@gmail.com";

if (mail($to_email, $subject, $body, $headers))
{
    echo "Email successfully sent to $to_email...";
}
else
{
    echo "Email sending failed!";
}
?>