<?php
   
   include 'connect.php';

   $id = $_GET['id'];

   $query= "DELETE FROM signup WHERE id =$id ";
    
   mysqli_query($conn,$query);

   

   header('location:addfriend.php'); 




?>