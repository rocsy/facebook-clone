<?php

include 'connect.php';
include 'bfnavbar.php';
$id = $_SESSION['userid'];

$file_name = "";
if (isset($_POST['submit'])) {
    if (isset($_FILES['image'])) {

        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_type = $_FILES['image']['type'];
        $folder = 'upload/' . $file_name;
        move_uploaded_file($file_tmp, $folder);

        $message = $_POST['message'];
        $id = $_SESSION['userid'];

        if (!empty($file_name)) {

            $query = "insert into post(image ,message,uploader)values('$file_name','$message','$id')";
            if ($run = mysqli_query($conn, $query)) {
            } else {
                echo "fail";
            }
        }
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js"></script>
    <!-- <script type="text/javascript" >
             function preventBack(){window.history.forward()};
             setTimeout("preventBack()",0);
             window.onunload=function(){null;}
    </script> -->

    <title>multiple post</title>
    <style>
        .card {
            padding: 20px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            transition: 0.3s;
            border-radius: 5px;
            width: 500px;
            height: auto;
            margin: auto;

        }

        .card:hover {
            box-shadow: 0, 8px 16px, 0 rgba(0, 0, 0, 0.2);
        }

        textarea {
            resize: none;
            overflow: hidden;
            min-height: 50px;
            max-height: 100px;
            padding-left: 20px;
            padding-top: 10px;
            width: 350px;
            background-color: #d3d9e2;
            color: white;
            font-weight: bold;
            border-radius: 5px;
            border: none;
            float: left
        }

        .text {
            margin: 10px;
            flex-direction: row;
        }

        #submit {
            margin-top: 20px;
            border-radius: 10px;
            background-color: #166fe5;
            height: 35px;
            width: 60px;
            color: white;
            border: none;
            text-align: center;
            display: flex;
            justify-content: center;
            font-weight: 500;
            text-transform: capitalize;
        }

        #image {
            float: left;
            margin-left: 15px;
        }
    </style>
</head>

<body>

    <center>
        <div class="card">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">

                <input type="file" name="image" onchange="readURL(this)" id="image" accept="image/png, image/jpg/, image/gif, image/jpeg" />

                <img id="blah" src="" alt="" />
                <div class="text">
                    <div>
                        <br><textarea name="message" oninput="auto_grow(this)" placeholder="What's on your mind ,<?php echo $_SESSION['username'] ?>"></textarea>
                    </div>
                    <div>
                        <span><input type="submit" name="submit" value="post" id="submit"></span>
                    </div>
                </div>
            </form>



            <script>
                function readURL(input) {
                    if (input.files && input.files[0]) {
                        var reader = new FileReader();

                        reader.onload = function(e) {
                            $('#blah')
                                .attr('src', e.target.result)
                                .width(100)
                                .height(100);
                        };

                        reader.readAsDataURL(input.files[0]);
                    }

                }
            </script>
        </div>

        <?php include 'display.php'  ?>

    </center>
    <script>
        function auto_grow(element) {
            element.style.height = "5px";
            element.style.height = (element.scrollHeight) + "px";
        }
    </script>
</body>

</html>