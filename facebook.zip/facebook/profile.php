<?php include 'bfnavbar.php'; ?>

<?php
// session_start();
include 'connect.php';
$email = $_SESSION['email'];
$query = "select * from signup where email='$email'";

$run = mysqli_query($conn, $query);
if (mysqli_num_rows($run) > 0) {
  $row = mysqli_fetch_array($run);
  // print_r($row['firstname']);
  $username = strtoupper($row['firstname'] . " " . $row['lastname']);
}
?>

<?php
$id = $_SESSION['userid'];

$file_name = "";
if (isset($_POST['submit'])) {
  if (isset($_FILES['image'])) {

    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $folder = 'upload/' . $file_name;
    move_uploaded_file($file_tmp, $folder);

    $id = $_SESSION['userid'];

    $query = "update signup set profile='$file_name' where id='$id'";
    if ($run = mysqli_query($conn, $query)) {
    } else {
       "fail";
    }
  }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <title>Document</title>
</head>
    
<style>
  #image{
       margin-left: 50px;
  }
</style>
<body>

  <center>

    <div class="card text-white bg-info mb-3" style="max-width: 20rem;">
      <div class="card-header">Header</div>
      <div class="card-body">

        <input type="name" value="<?php echo $row['firstname'] ?>"><br><br>
        <input type="name" value="<?php echo $row['lastname'] ?>"><br><br>
        <input type="email" value="<?php echo $row['email'] ?>"><br><br>
        <input type="name" value="<?php echo $row['date'] ?>"><br><br>
        <input type="name" value="<?php echo $row['gender'] ?>"><br><br>


        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">

          <input type="file" name="image" onchange="readURL(this)" id ="image" />

          <div>
            <img id="blah" src="" alt="" />
          </div>


          <script>
            function readURL(input) {
              if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                  $('#blah')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(150);
                };
             
                reader.readAsDataURL(input.files[0]);
              }
            
            }

          </script>
          

          <br> <input type="submit" name="submit" value="profile update" class="submit" id="pageload">
        </form>
      </div>
    </div>
  

  </center>
             
  <script>
       $(document).ready(function(){
         $('#pageload').click(function(){
          setTimeout(() => {
           window.location.reload(true);
         }, 3000);
         })
         
       })
  </script>
</body>
</html>