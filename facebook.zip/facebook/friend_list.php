<?php include 'bfnavbar.php'; ?>

<?php
include 'connect.php';
// session_start();
$ids = $_SESSION['userid'];
// echo $ids;
$query  = "SELECT * FROM req_accept inner join signup on req_accept.recever=signup.id where req_accept.sender='$ids'";

$run = mysqli_query($conn, $query);

while ($res = mysqli_fetch_array($run)) {


?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <style>
        .profile {
            width: 200px;
            height: 100px;
            margin-top: 30px;
            border-radius: 10px;
            padding-top: 5px;

            background-color: whitesmoke;
            padding: 10px 10px;
            padding-left: 15px;
            border: 1px solid blue;
            border-radius: 5px;
            box-shadow: 2px 2px 2px 2px;
        }
        #unfriend{
             text-decoration: none;
        }
    </style>

    <body>
        <center>
            <div class="profile">

                <img src="upload/<?php echo $res['profile'] ?>" width="40px" height="40px" />
                <?php echo $res['firstname'] ?><?php echo $res['lastname'] ?><br>
                <?php echo  $res['id'] ?>
                <button class="btn btn-warning" id="btn1">
                    <a href="remove_friend.php?id=<?php echo $res['recever'] ?>" id="unfriend">unfriend</a>
                </button>

            </div>
        </center>

    <?php
}
    ?>
    </body>

    </html>