<?php
include 'connect.php';

$firsterror = $lasterror = $passerr = $email = $firstname = $lastname = $dateerr = $emailerr = '';

if (isset($_POST['submit'])) {


    if (empty($_POST["firstname"])) {
        $firsterror = "firstname is mandatory";
    } else {
        $firstname = $_POST["firstname"];
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z-' ]*$/", $firstname)) {
            $firsterror = "Only letters allowed";
        }
    }

    if (empty($_POST["lastname"])) {
        $lasterror = "lastname is mandatory";
    } else {
        $lastname = $_POST["lastname"];
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z-' ]*$/", $firstname)) {
            $lasterror = "Only letters allowed";
        }
    }

    if (empty($_POST["email"])) {
        $emailerr = "email is mandatory";
    } else {
        $email = $_POST['email'];
    }


    if (empty($_POST['password'])) {
        $passerr = 'password must have entered';
    } else {
        $password = $_POST['password'];
        $uppercase = preg_match('@[A-Z]@', $password);
        $lowercase = preg_match('@[a-z]@', $password);
        $number    = preg_match('@[0-9]@', $password);
        $specialChars = preg_match('@[^\w]@', $password);

        if (strlen($password) < 8) {
            $passerr = 'Password should be at least 8 characters ';
        }
        if (!$uppercase) {
            $passerr = 'one uppercase mandatory';
        }
        if (!$lowercase) {
            $passerr = 'one lowercase mandatory';
        }
        if (!$specialChars) {
            $passerr = 'one specialChars mandatory';
        }
        if (!$number) {
            $passerr = 'one number mandatory';
        } else {
            $password = $_POST['password'];
        }
    }

    if (empty($_POST['year'])) {
        $dateerr = "date is mandatory";
    } elseif (empty($_POST['month'])) {
        $dateerr = "date is mandatory";
    } elseif (empty($_POST['day'])) {
        $dateerr = "date is mandatory";
    } else {
        $year = $_POST['year'];
        $month = $_POST['month'];
        $day = $_POST['day'];
        // $dobArr = array($_POST['year'] . "-" . $_POST['month'] . "-" . $_POST['day']);
        // $date = implode('-', $dobArr);
        $date = $year . '-' . $month . '-' . $day;
    }

    $token = bin2hex(random_bytes(15));

    $mobilequery = "select * from signup where email='" . $email . "'";

    if ($result = mysqli_query($conn, $mobilequery)) {

        if ($result->num_rows > 0) {
            // print_r(mysqli_fetch_array($result));

            echo "<br>";
            $emailerr = 'email is already exits';
            $err = 1;
        }
    }



    if (empty($firsterror) && empty($lasterror) && empty($emailerr) && empty($dateerr) && empty($passerr)) {

        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $pass = md5($password);
        $gender = $_POST['gender'];
        // $date = date("y-m-d", strtotime($_POST['date']));
        $date = $date;


        $query = "insert into signup(firstname,lastname,email,password,gender,date,token,status) values('$firstname','$lastname','$email','$pass','$gender','$date','$token','inactive')";
        if ($run = mysqli_query($conn, $query)) {

            echo "<script> alert('data saved successfully');</script>";
            header('location:login.php');
            $_SESSION['msg'] = "successfully login";
        }
    } else {
        // echo 'fail';
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
    <style>
        #input1 {
            margin-left: 5px;
            height: 35px;
        }

        #input2 {
            height: 35px;
        }

        #input2:focus {
            outline: none !important;
            border-color: #719ECE;
            box-shadow: 0 0 10px #719ECE;
        }

        .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            transition: 0.3s;
            border-radius: 5px;
            width: 400px;
            height: 470px;
        }

        .card:hover {
            box-shadow: 0, 8px 16px, 0 rgba(0, 0, 0, 0.2);
        }

        button {
            width: 200px;
            height: 40px;
            background-color: #00a400;
            border-radius: 10px;
            border: none;
            color: white;
        }

        a {
            padding-top: 10px;
            text-decoration: none;
            color: #166fe5;
            margin-top: 10px;
        }

        h6 {
            margin-top: 10px;
        }

        h3 {
            margin-top: 30px;
        }

        .formcontrol {
            width: 110px;
            height: 35px;
            margin-right: 10px;
            margin-bottom: 30px;
        
        }

        .errorColor {
            color: red;
        }
        .myradio{
            /* flex-direction: row; */
            margin-left: 10px;

        }
        .style {
            border: 1px solid gray;
            
            margin-left: 5px;
            margin-right: 9px;
            margin-bottom: 15px;
            float: left;
            width: 110px;
            height: 35px;
            text-align: center;
            color: black;
            margin-top: 2px;
            align-items: center;
        }
    </style>
</head>

<body>
    <center>
        <div class="heading">
            <div>
                <img src="assets/facebook.png" width="200px" height="100px" />
            </div>
            <div class="card">

                <h3> Create a new account </h3>
                <h6>it's quick and easy </h6>

                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

                    <input type="text" name="firstname" value="" placeholder="firstname" id="input1" /><span><input type="text" id="input1" name="lastname" value="" placeholder="Surname" /></span><br>
                    <span class="errorColor">* <?php echo $firsterror; ?></span> <span class="errorColor">* <?php echo $lasterror; ?></span>


                    <input type="email" name="email" id="input2" value="" placeholder="email" /><br>
                    <span class="errorColor">* <?php echo $emailerr; ?><br>
                        <input type="password" name="password" id="input2" value="" placeholder="password" /><br>
                        <span class="errorColor">* <?php echo $passerr; ?><br>
                            <div class="myradio">
                                <div class="style">
                                    <input type="radio" id="gender" name="gender" value="male" checked>Male</input>
                                </div>
                                <div class="style">
                                    <input type="radio" id="gender" name="gender" value="female">Female</input>
                                </div>
                                <div class="style">
                                    <input type="radio" id="gender" name="gender" value="other">other</input><br><br>
                                </div>
                            </div>
                            <!-- <input type="date" name="date"><br>
                     <span class="errorColor">* <?php echo $dateerr; ?> -->

                            <span>
                                <select name="year" id="year" class="formcontrol">
                                    <option value="--" selected>Year</option>
                                    <?php
                                    for ($i = date('Y'); $i > 1899; $i--) {
                                        $birthdayYear = '';
                                        $selected = '';
                                        if ($birthdayYear == $i) $selected = ' selected="selected"';
                                        print('<option value="' . $i . '"' . $selected . '>' . $i . '</option>' . "\n");
                                    }
                                    ?>
                                </select>
                            </span>
                            <span>
                                <select name="month" id="month" onchange="" class="formcontrol" size="1">
                                    <option value="--" selected>Month</option>
                                    <?php for ($i = 1; $i <= 12; $i++) : ?>
                                        <option value="<?php echo ($i < 10) ? '0' . $i : $i; ?>"><?php echo $i; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </span>
                            <span>
                                <select name="day" id="day" onchange="" class="formcontrol" size="1">
                                    <option value="--" selected>Day</option>
                                    <?php for ($i = 1; $i <= 31; $i++) : ?>
                                        <option value="<?php echo ($i < 10) ? '0' . $i : $i; ?>"><?php echo $i; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </span>

                            <br><button type="submit" name="submit" value="SignUp" class="submit">Signup</button><br>
                            <a href="login.php">Already have an account</a>
                </form>
            </div>

        </div>

    </center>


</body>

</html>