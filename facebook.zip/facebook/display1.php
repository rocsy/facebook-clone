<?php

include 'connect.php';

if(isset($_POST['liked'])){
   $postid=$_POST['postid'];
   $result=mysqli_query($conn,"select * from post where postid= $postid");
   $row=mysqli_fetch_array($result);
   $n=$row['likes'];
   mysqli_query($conn,"update post set likes = $n+1 where id=$postid");
         mysqli_query($conn,"insert into likes(userid,postid) values(1,$postid)");
         
}

if(isset($_POST['unliked'])){
    $postid=$_POST['postid'];
    $result=mysqli_query($conn,"select * from post where postid= $postid");
    $row=mysqli_fetch_array($result);
    $n=$row['likes'];
    mysqli_query($conn,"delete from likes where postid=$postid and userid=1");
    mysqli_query($conn,"update post set likes = $n-1 where id=$postid");
 }
?>
      
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <style>
        .container {
            margin-top: 10px;
            width: 500px;
            height: 400px;
            border: orange;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            display: flex;
        }
        .img1 {
            border: solid 2px green;
            border-radius: 20px;
        }
    </style>

    <body>
    <div class="content">

<?php
     $selectQuery = " select * from post  ";
     
$query = mysqli_query($conn, $selectQuery);
          
while ($res = mysqli_fetch_array($query)) {?>
    
    <div class="post">

    <br><img src="upload/<?php echo $res['image']?> "class="img1" width="500" height="350px" ?/><br>
   
    <?php

    $result = mysqli_query($conn,"select * from likes where userid=1 AND postid = ".$res['id']." ");
	echo $res['id'];
     if(mysqli_num_rows($result)==1){?>
        <span> <a href=""class="unlike" id="<?php echo $res['id'] ?>">unlike</a></span>

     <?php } else
     { ?>
        <span> <a href="" class="like" id="<?php echo $res['id'] ?>">like</a></span>

    <?php } ?>
   
   
      </div>
<?php
}
?>
     </div>

       <script>
           $(document).ready(function(){
                $('.like').click(function(){
                    var postid=$(this).attr('id');
                    alert(postid);
                    $.ajax({
                        url:'display.php',
                        type:'post',
                        async:false,
                        data:{
                                'liked': 1,
                                'postid': postid,
                        },
                        success:function(){
                            document.getElementsByClassName('.like')="unlike";
                        }
                    });
                });


                $('.unlike').click(function(){
                    var postid=$(this).attr('id');
                    $.ajax({
                        url:'display.php',
                        type:'post',
                        async:false,
                        data:{
                                'unliked':1,
                                'postid':postid
                        },
                        success:function(){
                            document.getElementBy('.unlike')="like";
                        }

                    });
                });
           })
       </script>
    </body>

    </html>