<?php
include 'connect.php';
session_start();
$emailerr = '';

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $_SESSION['email'] = $email;


    if (empty($_POST["email"])) {
        $emailerr = "email is mandatory";
    }


    if (empty($emailerr)) {
        $emailquery = "select * from signup where email='$email'";
        $query = mysqli_query($conn, $emailquery);
        $emailcount = mysqli_num_rows($query);

        if ($emailcount) {

            $userdata = mysqli_fetch_array($query);
            $token = $userdata['token'];

            $subject = "password reset";
            $body = "hi, click here too activate your account 
                   http://localhost/php/facebook/forgot_success.php?token=$token";
            $sender_email = "From: atul19462@gmail.com";
            if (mail($email, $subject, $body, $sender_email)) {
                //    header('location : login.php');
                // echo 'mail sent successfully to this ', $email, ' check the mail';
            } else {
                echo "*email sending failed";
            }
        } else {
            $emailerr = "email not found";
        }
    }
}

IP:52.14.230.175
User - ubuntu



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">

    <title>Document</title>
    <style>
        h2 {
            padding-top: 50px;
            color: rgb(9, 36, 245);
            margin-bottom: 20px;
        }

        .card1 {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            padding: 30px;
            transition: 0.3s;
            border-radius: 5px;
            width: 300px;
            height: auto;
        }

        .card1:hover {
            box-shadow: 0, 8px 16px, 0 rgba(0, 0, 0, 0.2);
        }

        input {
            width: 200px;
            height: 25px;

        }

        button {
            height: 30px;
            width: 100px;
            color: white;
            background-color: blue;
            border: none;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <center>
        <div>
            <h2>Forgotten Password </h2>
            <div class="card1">

                <form method="post" action="<?php echo  htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                    <input type="email" name="email" placeholder="email"><br>
                    <?php echo $emailerr ?><br>
                    <button type="submit" name="submit">Send Mail</button>
                </form>
                <a href="login.php">Already have an account</a>

            </div>
        </div>
    </center>

</body>

</html>