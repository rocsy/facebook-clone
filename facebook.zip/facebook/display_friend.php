<?php
   session_start();
   include 'connect.php';
   $recever_id=$_GET['id'];
    echo $recever_id;
    $sender_id=$_SESSION['userid'];
    echo $sender_id;

    $query="insert into req_accept (recever,sender) values ($recever_id,$sender_id) ";
    $run=mysqli_query($conn,$query);
    $q="insert into req_accept (recever,sender) values ($sender_id,$recever_id)";
    $r=mysqli_query($conn,$q);


   
    $q_del="delete from addfriend where user_id='$recever_id' and friend_id='$sender_id' ";
    $D_run=mysqli_query($conn,$q_del);
    header('location:req_friend.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>



</body>
</html>