<?php include 'bfnavbar.php'; ?>

<?php
include 'connect.php';
// session_start();
$ids = $_SESSION['userid'];
// echo $ids;


$query = "SELECT * FROM addfriend inner join signup on addfriend.friend_id=signup.id where signup.id='$ids'";
$run = mysqli_query($conn, $query);
while ($res = mysqli_fetch_array($run)) {
 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <title>Document</title>

    <style>
    .profile {
        width: 200px;
        height: 100px;
        margin-top: 30px;
        background-color: brown;
        border-radius: 10px;
        padding-top: 5px;
    }
</style>
</head>
<body>  

            
    <center>

<div class="profile">
             

            <img src="assets/profile.png" width="40px" height="40px" />
            <?php echo $res['firstname'] ?><?php echo $res['lastname'] ?><br>
            <?php echo  $res['user_id'] ?>
            <button class="btn btn-warning" id="btn1">
                <a href="display_friend.php?id=<?php echo $res['user_id'] ?>">accept</a>
            </button>

        </div>
    </center>

<?php
}
?>
<!-- 
<script>
    $(document).ready(function(){
        $('#btn1').html('sending request');
    })
            
</script> -->

</body>

</html>