<?php
session_start();

include 'connect.php';
$email = $_SESSION['email'];

$query = "select * from signup where email='$email'";

$run = mysqli_query($conn, $query);
if (mysqli_num_rows($run) > 0) {
  $row = mysqli_fetch_array($run);
  // print_r($row['firstname']);
  $username = strtoupper($row['firstname'] . " " . $row['lastname']);
  $_SESSION['username'] = $username;
  $id = $row['id'];
  $_SESSION['userid'] = $row['id'];
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <title>Document</title>
  <style>
    #logout {
      color: white;
      text-decoration: none;
      font-weight: 600;

    }

    #username {
      font-style: italic;
      font-weight: bold;

    }

    /* img {
      border-radius: 50%;
    } */

    #image {
      width: 150px;
      height: 70px;
    }

    .navbar {
      height: 60px;
      padding-top: 5px;
      margin-bottom: 30px;

    }

    #navbar:hover {
      box-shadow: 0, 8px 16px, 0 rgba(0, 0, 0, 0.2);
    }
    #myimg{
            border-radius: 50%;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-white">
    <div class="container-fluid">
      <a class="navbar-brand " href="#"><img src="assets/facebook.png" width="120px" height="50px" id="image" /></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 mx-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="home.php"><img src="assets/home.png" width="40px" height="40px" /></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="addfriend.php"><img src="assets/add.png" width="50px" height="50px" alt=""></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="req_friend.php"><img src="assets/market.png" width="45px" height="45px" alt=""></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="friend_list.php"><img src="assets/game.png" width="40px" height="40px" alt=""></a>
          </li>

        </ul>
        <?php
        $selectQuery = " select *from signup  where id='$id'";

        $query = mysqli_query($conn, $selectQuery);

        // $nums=mysqli_num_rows($query); //for no of rows in my database
        $res = mysqli_fetch_array($query); {

        ?>
           <a class="nav-link" href="profile.php"> <img src="upload/<?php echo $res['profile'] ?>" id='myimg' width="45px" height="45px" alt=""></a>

        <?php
        }
        ?>

        <span class="nav-link" id="username"><?php echo $username ?> </span>
        <!-- <span><?php echo  $_SESSION['userid'] ?></span> -->

        <button type="button" class="btn btn-primary"><a href="logout.php" id="logout">logout</a></button>

      </div>
    </div>
  </nav>

</body>
</html>